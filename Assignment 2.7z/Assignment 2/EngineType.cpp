#include <iostream>
#include "EngineType.h"

using namespace std;

// Set the data value
void EngineType::setInfo(int x, float y, double z){

    maxrpm = x;
    HP = y;
    Tourque = z;
}


// Get user input for the data
void EngineType::getInfo(){
    cout << "Input RPM: ";
    cin >> maxrpm;
    cout << "Input Tourque: ";
    cin >> Tourque;
}



// Calculation Function to calculate the Torque
void EngineType::calcTorque(){

    double power;

    power = HP * 1.013869738;

    Tourque = power / (3.14159265359 * maxrpm);

}

// Calculation Function to calculate the Horsepower
void EngineType::calcHP(){

    double power;

    power = Tourque * 3.14159265359 * maxrpm;

    HP = power / 1.013869738;
}
