#include <iostream>
#include "EngineType.h"

using namespace std;

int main (){

    // Creating object of class using default constructor

    EngineType engine1;
    EngineType engine2;

    engine1.setInfo(5000, 300, 0); // Fix value that given to the data for engine1
    engine1.calcTorque(); // Calculation are using function in the class

    engine2.getInfo(); // Function to get input from the user (Torque and Max RPM)
    engine2.calcHP(); // Calculation to calculate the Horsepower

    cout << endl;
    cout << endl;

    // Function to display the data for both object.
    engine1.printInfo();
    engine2.printInfo();
    cout << endl;
    cout << endl;

    return 0;
}
