#include <iostream>
using namespace std;



/*-------------------------------------------------------------------Class Setup-----------------------------------------------------------------------------------*/
class EngineType { // class are setup as EngineType

// Private object are define that can't be access from outside the class.
    int maxrpm;
    float HP;
    double Tourque;

// Public Class are define so it can be manipulate via outside the class.
public :


// Construct declaration to setup default data are all 0
    EngineType (){
        maxrpm = 0;
        HP = 0;
        Tourque = 0;
    }

// Function inside the class to display data of the program.
    void printInfo(){
    cout << "Max RPM (Rotation Per Minute) :"<< maxrpm << endl;
    cout << "Horsepower :" << HP << endl;
    cout << "Torque : "<< Tourque << endl;
    }

    void setInfo (int, float, double);  //---------------------------

    void getInfo();                     //  Function Prototype in the Class

    void calcTorque();                  //

    void calcHP();                      // --------------------------

    ~EngineType(){
    cout << "Object Destructed" << endl; // Destructor declared
    }
};
